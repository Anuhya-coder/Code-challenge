import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { EnrolleeService } from '../enrollee.service';

export interface enroll {
  "id": string,
  "active": boolean,
  "name": string,
  "dateOfBirth": string
}

@Component({
  selector: 'app-enrollee-table',
  templateUrl: './enrollee-table.component.html',
  styleUrls: ['./enrollee-table.component.scss']
})
export class EnrolleeTableComponent implements OnInit {
  displayedColumns: string[] = ['id', 'status', 'name', 'dateOfBirth', 'Action'];
  dataSource;

  constructor(private enrollService : EnrolleeService,private router: Router
    ) { }

  ngOnInit() {
    const data = this.enrollService.getData().subscribe(item =>{
      this.dataSource = item;
    })
  }

  edit(id){
    this.router.navigate([`/editenroll/${id}`]);
  }

}
