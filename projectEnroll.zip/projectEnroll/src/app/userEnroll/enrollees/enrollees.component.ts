import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-enrollees',
  templateUrl: './enrollees.component.html',
  styleUrls: ['./enrollees.component.scss']
})
export class EnrolleesComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
   
  }

}
