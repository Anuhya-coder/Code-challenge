import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { EnrolleeService } from '../enrollee.service';

@Component({
  selector: 'app-enrollee-form',
  templateUrl: './enrollee-form.component.html',
  styleUrls: ['./enrollee-form.component.scss']
})
export class EnrolleeFormComponent implements OnInit {
  public editForm: FormGroup;
  submitted = false;
  public enroll = {
    id : "",
    status : "",
    name : "",
    dob : ""
  }

  

  constructor(private fb: FormBuilder,private route: ActivatedRoute,private enrollService : EnrolleeService) { 
    this.editForm = this.fb.group({
      id: '',
      status: '',
      name: ['', Validators.required],
      dob:''
    });
  }

  ngOnInit() {
    let data = this.route.snapshot.params['id'];
    this.enrollService.getData().subscribe(item =>{
      let apidata = item;
      let filterData = apidata.filter(i => i.id == data)
      if(filterData){
        this.editForm = this.fb.group({
          id: filterData[0].id,
          status: filterData[0].active,
          name: [filterData[0].name, Validators.required],
          dob:filterData[0].dateOfBirth
        });
      }
    })
  }
  get f() { return this.editForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.editForm.invalid) {
        return;
    }

    // display form values on success
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.editForm.value, null, 4));
}
}
