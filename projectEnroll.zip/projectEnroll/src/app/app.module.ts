import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EnrolleesComponent } from './userEnroll/enrollees/enrollees.component';
import { EnrolleeService } from './userEnroll/enrollee.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatTableModule} from '@angular/material/table';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import { EnrolleeTableComponent } from './userEnroll/enrollee-table/enrollee-table.component';
import { EnrolleeFormComponent } from './userEnroll/enrollee-form/enrollee-form.component';

@NgModule({
  declarations: [
    AppComponent,
    EnrolleesComponent,
    EnrolleeTableComponent,
    EnrolleeFormComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatCardModule,
    MatIconModule,
    ReactiveFormsModule
  ],
  providers: [EnrolleeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
