import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EnrolleeFormComponent } from './userEnroll/enrollee-form/enrollee-form.component';
import { EnrolleesComponent } from './userEnroll/enrollees/enrollees.component';

const routes: Routes = [
  { path: '', component: EnrolleesComponent },
  { path: 'editenroll/:id', component: EnrolleeFormComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
